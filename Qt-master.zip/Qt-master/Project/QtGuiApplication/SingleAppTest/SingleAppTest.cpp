#include "SingleAppTest.h"

SingleAppTest::SingleAppTest(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}
