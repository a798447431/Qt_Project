#include "SingleAppTest2.h"

SingleAppTest2::SingleAppTest2(QWidget *parent)
    : QWidget(parent)
{
    ui.setupUi(this);
}
