# ToosMainWindow

日常开发经常写一些小工具，界面来不及更改，现开发了一个通用的工具主界面，方便以后快速拿来就用

1、主窗口<br>
  ![image](https://github.com/lesliefish/Qt/blob/master/Tools/ToolsMainWindow/pic/main.png)
  <br>  <br>
2、退出<br>
  ![image](https://github.com/lesliefish/Qt/blob/master/Tools/ToolsMainWindow/pic/info.png)
  <br>  <br>
3、警告提示<br>
  ![image](https://github.com/lesliefish/Qt/blob/master/Tools/ToolsMainWindow/pic/warning.png)
    <br>  <br>
4、关于<br>
  ![image](https://github.com/lesliefish/Qt/blob/master/Tools/ToolsMainWindow/pic/about.png)
<br>

##### 有空添加功能

