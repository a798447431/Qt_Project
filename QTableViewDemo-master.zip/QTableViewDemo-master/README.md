# QTableViewDemo

主要是表头添加checkBox。

还有一些选中的问题。